CREATE DATABASE  IF NOT EXISTS `book_rental` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `book_rental`;
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: book_rental
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `author`
--

DROP TABLE IF EXISTS `author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `author` (
  `authorid` bigint NOT NULL AUTO_INCREMENT,
  `author_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`authorid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `author`
--

LOCK TABLES `author` WRITE;
/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` VALUES (4,'J. K. Rowling'),(5,'Jeff Kinney'),(6,'Stephenie Meyer'),(8,'E. Bright Wilson, Jr.'),(9,'Colleen Hoover'),(10,'Ana Huang'),(11,'George R. R. Martin');
/*!40000 ALTER TABLE `author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `bookid` bigint NOT NULL AUTO_INCREMENT,
  `available_copies` int NOT NULL,
  `book_name` varchar(255) DEFAULT NULL,
  `description` text,
  `imageurl` varchar(255) DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `rental_price` double NOT NULL,
  `stock` varchar(255) DEFAULT NULL,
  `total_copies` int NOT NULL,
  `authorid` bigint DEFAULT NULL,
  `publisher_id` bigint DEFAULT NULL,
  PRIMARY KEY (`bookid`),
  KEY `FKhcj0e0ky3ftaweqnllqfwbn99` (`authorid`),
  KEY `FKgtvt7p649s4x80y6f4842pnfq` (`publisher_id`),
  CONSTRAINT `FKgtvt7p649s4x80y6f4842pnfq` FOREIGN KEY (`publisher_id`) REFERENCES `publisher` (`publisherid`),
  CONSTRAINT `FKhcj0e0ky3ftaweqnllqfwbn99` FOREIGN KEY (`authorid`) REFERENCES `author` (`authorid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (9,11,'Harry Potter and the Chamber of Secrets','Throughout the summer holidays after his first year at Hogwarts School of Witchcraft and Wizardry, Harry Potter has been receiving sinister warnings from a house-elf called Dobby. ','https://covers.openlibrary.org/b/id/15095437-L.jpg','1999-05-05',22,'In Stock',11,4,3),(10,1,'Harry Potter and the Prisoner of Azkaban','For Twelve long years, the dread fortress of Azkaban held an infamous prisoner named Sirius Black. Convicted of killing thirteen people with a single curse, he was said to be the heir apparent to the Dark Lord, Voldemort.','https://covers.openlibrary.org/b/id/14852024-L.jpg','2007-07-04',15,'In Stock',2,4,3),(11,2,'Harry Potter and The Goblet of Fire 4','The fourth book in the Harry Potter franchise sees Harry returning for his fourth year at Hogwarts School of Witchcraft and Wizardry, along with his friends, Ron and Hermione ','https://covers.openlibrary.org/b/id/15096178-L.jpg','2013-07-10',5,'In Stock',3,4,4),(12,3,'Nevykėlio dienoraštis','Greg skriver dagbok for alle sine fremtidige fans, han må bare takle mellomstadiet først. Som nummer to i en søskenflokk på tre er han skviset inn mellom en sjefete storebror og en sippete lillebror. Foreldrene er velmenende, men helt håpløse ifølge Greg.','https://covers.openlibrary.org/b/id/15103624-L.jpg','2002-05-13',2,'In Stock',4,5,5),(13,6,'Dog Days (Diary of a Wimpy Kid book 4)','In Dog Days, book 4 of the Diary of a Wimpy Kid series from #1 international bestselling author Jeff Kinney, it\'s summer vacation, the weather\'s great, and all the kids are having fun outside. So where\'s Greg Heffley? ','https://covers.openlibrary.org/b/id/14812500-L.jpg','2012-07-16',9,'In Stock',6,5,5),(14,8,'Diary of a Wimpy Kid Rodrick Rules','Greg Heffley tells about his summer vacation and his attempts to steer clear of trouble when he returns to middle school and tries to keep his older brother Rodrick from telling everyone about Greg\'s most humiliating experience of the summer. ','https://covers.openlibrary.org/b/id/14819388-L.jpg','2008-07-21',3,'In Stock',8,5,5),(17,2,'Twisted Love','He has a heart of ice … but for her, he\'d burn the world. Alex Volkov is a devil blessed with the face of an angel and cursed with a past he can\'t escape. Driven by a tragedy that has haunted him for most of his life, his ruthless pursuits for success and vengeance leave little room for matters of the heart.','https://covers.openlibrary.org/b/id/13886065-L.jpg','2021-08-26',2,'In Stock',2,10,7),(18,3,'Twisted Games','She can never be his…but he’s taking her anyway.\r\n\r\nStoic, broody, and arrogant, elite bodyguard Rhys Larsen has two rules: 1) Protect his clients at all costs 2) Do not become emotionally involved. Ever. ','https://covers.openlibrary.org/b/id/14845965-L.jpg','2021-08-19',4,'In Stock',3,10,7),(19,12,'Twisted Lies','He\'ll do anything to have her...including lie.\r\n\r\nCharming, deadly, and smart enough to hide it, Christian Harper is a monster dressed in the perfectly tailored suits of a gentleman.\r\n\r\nHe has little use for morals and even less use for love, but he can’t deny the strange pull he feels toward the woman living just one floor below him.\r\n\r\nShe’s the object of his darkest desires, the only puzzle he can’t solve. And when the opportunity to get closer to her arises, he breaks his own rules to offer her a deal she can’t refuse.\r\n\r\nEvery monster has their weakness. She’s his.\r\n\r\nHis obsession. ','https://covers.openlibrary.org/b/id/14860233-L.jpg','2022-08-23',6,'In Stock',12,10,7),(20,4,'King of Wrath','Ruthless. Meticulous. Arrogant.\r\nDante Russo thrives on control, both personally and professionally.\r\nThe billionaire CEO never planned to marry until the threat of blackmail forces him into an engagement with a woman he barely knows.\r\nVivian Lau, jewelry heiress, and daughter of his newest enemy.\r\nIt doesn’t matter how beautiful or charming she is. He\'ll do everything in his power to destroy the evidence and their betrothal. There’s only one problem: now that he has her...he can\'t bring himself to let her go. ','https://covers.openlibrary.org/b/id/13588136-L.jpg','2022-08-25',6,'In Stock',4,10,7),(21,1,'It Ends With Us','Lily hasn’t always had it easy, but that’s never stopped her from working hard for the life she wants. She’s come a long way from the small town where she grew up—she graduated from college, moved to Boston, and started her own business. And when she feels a spark with a gorgeous neurosurgeon named Ryle Kincaid, everything in Lily’s life seems too good to be true. ','https://covers.openlibrary.org/b/id/15069202-L.jpg','2016-08-02',3,'In Stock',1,9,6),(22,1,'It Starts with Us','Lily and her ex-husband, Ryle, have just settled into a civil coparenting rhythm when she suddenly bumps into her first love, Atlas, again. After nearly two years separated, she is elated that for once, time is on their side, and she immediately says yes when Atlas asks her on a date. ','https://covers.openlibrary.org/b/id/14416611-L.jpg','2023-08-23',9,'In Stock',2,9,6),(23,3,'Verity','Lowen Ashleigh is a struggling writer on the brink of financial ruin when she accepts the job offer of a lifetime. Jeremy Crawford, husband of bestselling author Verity Crawford, has hired Lowen to complete the remaining books in a successful series his injured wife is unable to finish. ','https://covers.openlibrary.org/b/id/13009038-L.jpg','2018-08-08',7,'In Stock',3,9,6),(24,4,'Heart Bones','Life and a dismal last name are the only two things Beyah\'s parents ever gave her. After carving her path all on her own, Beyah is well on her way to bigger and better things, thanks to no one but herself. With only two short months separating her from the future she\'s built and the past she desperately wants to leave behind, an unexpected death leaves Beyah with no place to go during the interim. ','https://covers.openlibrary.org/b/id/14546652-L.jpg','2020-08-31',5,'In Stock',4,9,6),(25,4,'Twilight','When seventeen-year-old Bella leaves Phoenix to live with her father in Forks, Washington, she meets an exquisitely handsome boy at school for whom she feels an overwhelming attraction and who she comes to realize is not wholly human. ','https://covers.openlibrary.org/b/id/14352258-L.jpg','2005-04-22',6,'In Stock',5,6,3),(26,3,'New Moon','Love stories. Horror fiction. Now in a Special Trade Demy Paperback Edition. The dramatic sequel to TWILIGHT, following the tale of Bella, a teenage girl whose love for a vampire gets her into trouble. I stuck my finger under the edge of the paper and jerked it under the tape. \'Shoot, \' I muttered when the paper sliced my finger. A single drop of blood oozed from the tiny cut. It all happened very quickly then. \'No!\' Edward roared ... ','https://covers.openlibrary.org/b/id/14852004-L.jpg','2006-05-02',5,'In Stock',3,6,4),(27,5,'Eclipse','As Seattle is ravaged by a string of mysterious killings and a malicious vampire continues her quest for revenge, Bella once again finds herself surrounded by danger. In the midst of it all, she is forced to choose between her love for Edward and her friendship with Jacob -- knowing that her decision has the potential to ignite the ageless struggle between vampire and werewolf. With her graduation quickly approaching, Bella has one more decision to make: life or death. But which is which? -- back cover. ','https://covers.openlibrary.org/b/id/12643339-L.jpg','2006-07-04',8,'In Stock',5,6,5),(28,3,'Breaking Dawn','When you loved the one who was killing you, it left you no options. How could you run, how could you fight, when doing so would hurt that beloved one? If your life was all you had to give, how could you not give it? If it was someone you truly loved? To be irrevocably in love with a vampire is both fantasy and nightmare woven into a dangerously heightened reality for Bella Swan. Pulled in one direction by her intense passion for Edward Cullen, and in another by her profound connection to werewolf Jacob Black, a tumultuous year of temptation, loss, and strife have led her to the ultimate turning point. ','https://covers.openlibrary.org/b/id/12643362-L.jpg','2008-05-03',7,'In Stock',3,6,3),(29,3,'An introduction to scientific research','This book is intended to assist scientists in planning and carrying out research. However, unlike most books dealing with the scientific method, which stress its philosophical rationale, this book is written from a practical standpoint. It contains a rich legacy of principles, maxims, procedures and general techniques that have been found useful in a wide range of sciences.','https://covers.openlibrary.org/b/id/315113-L.jpg','1952-04-03',8,'In Stock',3,8,6),(30,5,'A Game of Thrones','A Game of Thrones is the inaugural novel in A Song of Ice and Fire, an epic series of fantasy novels crafted by the American author George R. R. Martin. Published on August 1, 1996, this novel introduces readers to the richly detailed world of Westeros and Essos, where political intrigue, power struggles, and magical elements intertwine.','https://covers.openlibrary.org/b/id/15093534-L.jpg','1996-03-02',7,'In Stock',5,11,8),(31,2,'A Clash of Kings','In this thrilling sequel to A Game of Thrones, George R. R. Martin has created a work of unsurpassed vision, power, and imagination. A Clash of Kings transports us to a world of revelry and revenge, wizardry and warfare unlike any we have ever experienced. ','https://covers.openlibrary.org/b/id/11291880-L.jpg','1998-05-04',6,'In Stock',2,11,8),(32,4,'A Storm of Swords','Here is the third volume in George R. R. Martin’s magnificent cycle of novels that includes A Game of Thrones and A Clash of Kings. As a whole, this series comprises a genuine masterpiece of modern fantasy, bringing together the best the genre has to offer. Magic, mystery, intrigue, romance, and adventure fill these pages and transport us to a world unlike any we have ever experienced. Already hailed as a classic, George R. R. Martin’s stunning series is destined to stand as one of the great achievements of imaginative fiction. ','https://covers.openlibrary.org/b/id/14614979-L.jpg','2000-03-02',7,'In Stock',4,11,8),(33,3,'A Feast for Crows','Few books have captivated the imagination and won the devotion and praise of readers and critics everywhere as has George R. R. Martin’s monumental epic cycle of high fantasy. Now, in A Feast for Crows, Martin delivers the long-awaited fourth book of his landmark series, as a kingdom torn asunder finds itself at last on the brink of peace . . . only to be launched on an even more terrifying course of destruction. ','https://covers.openlibrary.org/b/id/14614972-L.jpg','2005-03-02',4,'In Stock',3,11,8),(34,3,'A Dance With Dragons','In the aftermath of a colossal battle, the future of the Seven Kingdoms hangs in the balance once again–beset by newly emerging threats from every direction. In the east, Daenerys Targaryen, the last scion of House Targaryen, rules with her three dragons as queen of a city built on dust and death. But Daenerys has three times three thousand enemies, and many have set out to find her. Yet, as they gather, one young man embarks upon his own quest for the queen, with an entirely different goal in mind. ','https://covers.openlibrary.org/b/id/14818128-L.jpg','2008-06-05',6,'In Stock',3,11,8);
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_category`
--

DROP TABLE IF EXISTS `book_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_category` (
  `book_categoryid` bigint NOT NULL AUTO_INCREMENT,
  `book_cat_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`book_categoryid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_category`
--

LOCK TABLES `book_category` WRITE;
/*!40000 ALTER TABLE `book_category` DISABLE KEYS */;
INSERT INTO `book_category` VALUES (1,'Fiction'),(2,'Non-Fiction'),(3,'Children'),(4,'Young Adult'),(5,'Biography'),(6,'Science'),(7,'History'),(8,'Fantasy'),(9,'Mystery'),(11,'Romance');
/*!40000 ALTER TABLE `book_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_category_map`
--

DROP TABLE IF EXISTS `book_category_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_category_map` (
  `bookid` bigint NOT NULL,
  `book_categoryid` bigint NOT NULL,
  KEY `FKo7aksvq0nqk5fd2qwyoy8f1vy` (`book_categoryid`),
  KEY `FKaob19w1325ji4f5i6r5f5wf9o` (`bookid`),
  CONSTRAINT `FKaob19w1325ji4f5i6r5f5wf9o` FOREIGN KEY (`bookid`) REFERENCES `book` (`bookid`),
  CONSTRAINT `FKo7aksvq0nqk5fd2qwyoy8f1vy` FOREIGN KEY (`book_categoryid`) REFERENCES `book_category` (`book_categoryid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_category_map`
--

LOCK TABLES `book_category_map` WRITE;
/*!40000 ALTER TABLE `book_category_map` DISABLE KEYS */;
INSERT INTO `book_category_map` VALUES (12,2),(12,3),(12,7),(13,2),(13,3),(13,4),(14,2),(14,3),(14,4),(10,1),(10,8),(10,9),(11,1),(11,4),(11,8),(11,9),(17,1),(17,11),(9,1),(9,8),(9,9),(18,2),(18,11),(19,1),(19,9),(19,11),(20,1),(20,11),(21,1),(21,9),(21,11),(22,1),(22,4),(22,11),(23,1),(23,3),(23,4),(23,11),(25,1),(25,8),(25,9),(25,11),(26,1),(26,6),(26,7),(26,8),(26,9),(26,11),(27,1),(27,6),(27,7),(27,8),(27,9),(27,11),(28,1),(28,6),(28,7),(28,8),(28,9),(28,11),(29,6),(30,1),(30,8),(31,1),(31,8),(32,1),(32,8),(33,1),(33,8),(34,1),(34,8);
/*!40000 ALTER TABLE `book_category_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow_record`
--

DROP TABLE IF EXISTS `borrow_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrow_record` (
  `borrowid` bigint NOT NULL AUTO_INCREMENT,
  `borrow_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reservationid` bigint DEFAULT NULL,
  `fine_amount` double DEFAULT NULL,
  PRIMARY KEY (`borrowid`),
  KEY `FKdh7dkpm7mpkrdadavdtc6snnc` (`reservationid`),
  CONSTRAINT `FKdh7dkpm7mpkrdadavdtc6snnc` FOREIGN KEY (`reservationid`) REFERENCES `reservation` (`reservationid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow_record`
--

LOCK TABLES `borrow_record` WRITE;
/*!40000 ALTER TABLE `borrow_record` DISABLE KEYS */;
INSERT INTO `borrow_record` VALUES (14,'2025-07-30','2025-07-31','2025-08-21','RETURNED',2,NULL),(15,'2025-07-30','2025-07-30',NULL,'BORROWING',6,NULL),(16,'2025-07-30','2025-07-29',NULL,'BORROWING',14,NULL),(17,'2025-08-01','2025-08-03',NULL,'BORROWING',7,NULL);
/*!40000 ALTER TABLE `borrow_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `is_read` bit(1) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `type` enum('DUE_SOON','OVERDUE') DEFAULT NULL,
  `borrowid` bigint DEFAULT NULL,
  `userid` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4y2v7g9aatt18lgxodnwfkw1e` (`borrowid`),
  KEY `FK2kcyyi3inwcr0sflvdi14vnwa` (`userid`),
  CONSTRAINT `FK2kcyyi3inwcr0sflvdi14vnwa` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`),
  CONSTRAINT `FK4y2v7g9aatt18lgxodnwfkw1e` FOREIGN KEY (`borrowid`) REFERENCES `borrow_record` (`borrowid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES (2,'2025-07-30 09:35:00.054803',_binary '','Your reserved book is overdue! (Book: Harry Potter and the Prisoner of Azkaban)','OVERDUE',16,3),(3,'2025-07-31 02:04:00.062645',_binary '','Your reserved book is overdue! (Book: Harry Potter and the Chamber of Secrets)','OVERDUE',15,3),(4,'2025-07-31 02:11:00.034969',_binary '','Reminder: Your reserved book is due in 2 days. (Book: Harry Potter and the Prisoner of Azkaban)','DUE_SOON',14,1),(5,'2025-08-01 02:00:00.025622',_binary '\0','Your reserved book is overdue! (Book: Harry Potter and the Prisoner of Azkaban)','OVERDUE',14,1);
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `publisher`
--

DROP TABLE IF EXISTS `publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `publisher` (
  `publisherid` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`publisherid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publisher`
--

LOCK TABLES `publisher` WRITE;
/*!40000 ALTER TABLE `publisher` DISABLE KEYS */;
INSERT INTO `publisher` VALUES (3,'UK','Arthur A. Levine Books'),(4,'UK','Bloomsbury'),(5,'UK','Puffin'),(6,'UK','Simon & Schuster'),(7,'US','Indy Pub'),(8,'UK','Harper Voyager');
/*!40000 ALTER TABLE `publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `reservationid` bigint NOT NULL AUTO_INCREMENT,
  `created_date` date DEFAULT NULL,
  `status` enum('CANCELLED','RESERVED','RETURNED') DEFAULT NULL,
  `bookid` bigint DEFAULT NULL,
  `userid` bigint DEFAULT NULL,
  `reserved_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`reservationid`),
  KEY `FK6h43oam15hoedgr70s05uos5o` (`bookid`),
  KEY `FKbmofx0u4skuijdcuekxaowjp2` (`userid`),
  CONSTRAINT `FK6h43oam15hoedgr70s05uos5o` FOREIGN KEY (`bookid`) REFERENCES `book` (`bookid`),
  CONSTRAINT `FKbmofx0u4skuijdcuekxaowjp2` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
INSERT INTO `reservation` VALUES (2,'2025-07-25','RESERVED',10,1,NULL),(6,'2025-07-26','RESERVED',9,3,NULL),(7,'2025-07-26','RESERVED',11,3,NULL),(11,'2025-07-26','RESERVED',12,3,NULL),(14,'2025-07-28','CANCELLED',10,3,NULL),(20,'2025-07-31','RESERVED',9,1,NULL),(21,'2025-08-01','CANCELLED',12,3,NULL),(22,'2025-08-06','RESERVED',25,3,NULL),(23,'2025-08-06','RESERVED',22,3,NULL);
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userid` bigint NOT NULL AUTO_INCREMENT,
  `created_date` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,'leducminh2934@gmail.com','Đức Minh Lê',NULL,'ADMIN',NULL,NULL,NULL,'',NULL),(3,'2025-07-25','admin1@gmail.com','Harper Voyager','$2a$10$jzATgjR56HOy1OSi1HihMOpK29bZOChdyYUogKHRFMohAvvkFOOU6','admin','/images/59df4805-7005-48e3-a1b8-2b897b4a9b0f_Twisted Love.jpg','2004-03-29','Male','123456',NULL),(4,'2025-07-25','minhldhe180598@fpt.edu.vn','Le Duc Minh (K18 HL)',NULL,'member','/images/5b895fd8-d595-4f97-8ab2-7bd2ca45a2de_hero.jpg','2000-01-01','male','',NULL),(5,'2025-07-25','minh1@gmail.com','minh1','$2a$10$IvPMZFqoDZoD979mRduAI.hcOHNpqrEY2b1/xZtbTL/IN5eEeEUnq','member','default.jpg','2000-01-01','male',NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-06 14:37:34
